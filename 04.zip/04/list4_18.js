var number = [10,20,30];
console.log(number.length);
