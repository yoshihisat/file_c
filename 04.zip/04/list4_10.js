var a = 10;
a += 1; //aの値に1が加算されて11になる
console.log(a);
