var favorites = {
  food:"カレー",
  color:"青",
  number:7

};
console.log(favorites.food);
console.log(favorites.color);
console.log(favorites.number);
