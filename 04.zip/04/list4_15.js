var number = [10,20,30];
number[3] = 99;
