var favorites = {
  food:"カレー",
  color:"青",
  number:7
};
