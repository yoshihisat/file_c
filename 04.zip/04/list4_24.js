var favorites = {
  food:"カレー",
  color:"青",
  number:7

};
favorites.sports = "サッカー" //要素が追加される
console.log(favorites.sports);
