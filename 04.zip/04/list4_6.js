var x = 123 + 456;
var y = "123" + "456";
console.log(x);
console.log(y);
