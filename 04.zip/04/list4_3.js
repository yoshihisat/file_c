var a;
a = 10;
a = 20;
