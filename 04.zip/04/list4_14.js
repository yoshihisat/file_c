var number = [10,20,30];
number[1] =50;
console.log(number[1]);
