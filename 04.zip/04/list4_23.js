var favorites = {
  food:"カレー",
  color:"青",
  number:7

};
console.log(favorites.food);
var key = "food";             //キーを一度変数に入れる
console.log(favorites[key]);
