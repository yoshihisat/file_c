var a = 10;
a += 5; //aの値に5が加算されて15になる
console.log(a);
