var a = 10;
a = a + 1;      //(a+1)は(10+1)なので、aの値が15で上書きされる
console.log(a);
