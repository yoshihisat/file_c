var number = [[10,20,30],[40,50,60]];
console.log(number[0][0]);
console.log(number[0][1]);
console.log(number[0][2]);
console.log(number[1][0]);
console.log(number[1][1]);
console.log(number[1][2]);
