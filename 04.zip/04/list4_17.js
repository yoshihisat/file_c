var number = [ ]; //空の配列の作成
number[0] = 10;
number[1] = 20;
number[2] = 30;
