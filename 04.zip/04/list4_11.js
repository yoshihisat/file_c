var a = 10;
a ++; //aの値に1が加算されて11になる
console.log(a);
