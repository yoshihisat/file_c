var a =10;
a = a + 5;//(a+5)は(10+5)なので、aの値が15で上書きされる
console.log(a);
